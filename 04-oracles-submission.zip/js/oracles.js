import assert from "assert";
export function generateInput(n) {
    function randomInt(min, max) {
        return Math.floor(Math.random() * (max - min)) + min;
    }
    function shuffleToGetPermutation(n) {
        for (let i = n.length - 1; i >= 1; i--) {
            const j = randomInt(0, i);
            const tempV = n[i];
            n[i] = n[j];
            n[j] = tempV;
        }
        return n;
    }
    const sample = [];
    for (let i = 0; i < n; i++) {
        sample.push(i);
    }
    const result = sample.map(() => {
        const perArr = shuffleToGetPermutation([...sample]);
        return perArr;
    });
    return result;
}
const NUM_TESTS = 400; // Change this to some reasonably large value
const N = 100; // Change this to some reasonable size
/**
 * Tests whether or not the supplied function is a solution to the stable matching problem.
 * @param makeStableMatching A possible solution to the stable matching problem
 * @throws An `AssertionError` if `makeStableMatching` in not a solution to the stable matching problem
 */
export function ConvertToObject(arr) {
    const result = arr.map((e) => {
        const intialObj = {};
        const obj = e.reduce((acc, e1) => {
            acc[e1] = e.indexOf(e1);
            return acc;
        }, intialObj);
        return obj;
    });
    return result;
}
export function stableMatchingOracle(makeStableMatching) {
    for (let i = 0; i < NUM_TESTS; ++i) {
        const companies = generateInput(N);
        const candidates = generateInput(N);
        const hires = makeStableMatching(companies, candidates);
        const objCompanies = ConvertToObject(companies);
        const objCandidates = ConvertToObject(candidates);
        function helper(e, e1, ComToCad) {
            const ComToCad1 = objCompanies[e.company][e1.candidate];
            const CadToCom1 = objCandidates[e1.candidate][e.company];
            const CadToCom2 = objCandidates[e1.candidate][e1.company];
            if (ComToCad1 < ComToCad && CadToCom1 < CadToCom2) {
                return false;
            }
            return true;
        }
        const cloneArr = [...hires];
        assert(companies.length === hires.length, "Hires length is correct.");
        assert(hires.every(e => {
            cloneArr.shift();
            return cloneArr.every(e1 => helper(e, e1, objCompanies[e.company][e.candidate]));
        }), "Assertion Error");
    }
}
// Part B
/**
 * Tests whether or not the supplied function follows the supplied algorithm.
 * @param makeStableMatchingTrace A possible solution to the stable matching problem and its possible steps
 * @throws An `AssertionError` if `makeStableMatchingTrace` does not follow the specified algorithm, or its steps (trace)
 * do not match with the result (out).
 */
export function stableMatchingRunOracle(makeStableMatchingTrace) {
    for (let i = 0; i < NUM_TESTS; ++i) {
        const companies = generateInput(N);
        const candidates = generateInput(N);
        const { trace, out } = makeStableMatchingTrace(companies, candidates);
        // This statement is here to prevent linter warnings about `trace` and `out` not being used.
        // Remove it as necessary.
        console.log(trace, out);
        // TODO: Assertions go here
    }
}
//# sourceMappingURL=oracles.js.map